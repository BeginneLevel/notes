RAIDERS OF CORRUPTION\misc icon Picked up these at a yardsale, there doesnt seem to be anything useful in there though
